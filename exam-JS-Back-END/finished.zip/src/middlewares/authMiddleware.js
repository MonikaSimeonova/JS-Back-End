const jwt = require('../lib/jwt')
const { SECRET } = require('../config/config');
const animalManager = require('../managers/animalManager');


exports.auth = async (req, res, next) => {
    const token = req.cookies['token'];

    if (token) {
        try {
            const decoredToken = await jwt.verify(token, SECRET);
            req.user = decoredToken;
            res.locals.user = decoredToken;
            res.locals.isAuthenticated = true;
            next();
        } catch (err) {
            res.clearCookie('token');
            res.redirect('/users/login');
        }
    } else {
        next();
    }
};

exports.isAuth = (req,res, next)=>{
    if(!req.user){
        res.redirect('/users/login')
    }
    next();
}

exports.isOwnerCheck = async(req, res, next)=>{
    const animal = await animalManager.getOne(req.params.id);
console.log(animal.owner._id);
    if(animal.owner._id == req.user._id){
        next()
    }else{
        res.redirect(`/animals/${req.params.id}/details`)
    }
};